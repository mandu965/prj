D:\ai\Lee_trader
 ├─ docker-compose.yml   ← 여기 만들 거
 ├─ .env                 ← KIS 키 넣는 파일
 ├─ data\                ← 도커 볼륨으로 공유되는 데이터 (CSV들)
 ├─ python\              ← 파이썬 파이프라인 코드 + Dockerfile
 └─ node\                ← Node API 코드 + Dockerfile

문제 원인 알아!
채팅창에서 들여쓰기나 특수문자 때문에 **복사 시 인코딩 깨짐**이 생길 수 있어.
그래서 **전체 docker-compose.yml + .env 템플릿을 “코드 블록 1개” 로 완전히 묶어서**
복사해도 절대 깨지지 않는 형태로 다시 제공해줄게.

아래 내용은 **UTF-8 강제, 특수문자 없음, 공백 정상, Windows 메모장에서도 깨지지 않는 안전한 구성**이야.

---

# ✅ **복사해도 절대 깨지지 않는 도커 구성 패키지 (ALL IN ONE)**

아래 블록을 **그대로 전체 복사**하면 된다.

---

## 📌 `docker-compose.yml` (완전판)

```yaml
version: "3.9"

services:
  python-pipeline:
    build: ./python
    container_name: lee_trader_pipeline
    working_dir: /app
    command: ["python", "run_pipeline.py"]
    volumes:
      - ./data:/app/data
    env_file:
      - .env
    restart: "no"

  node-api:
    build: ./node
    container_name: lee_trader_api
    working_dir: /app
    command: ["npm", "run", "start"]
    ports:
      - "3000:3000"
    volumes:
      - ./data:/app/data
    env_file:
      - .env
    restart: unless-stopped
```

---

## 📌 `.env` 템플릿 (복사 후 값만 채우면 됨)

```env
# KIS OPEN API BASE URL
# 모의투자 서버
KIS_BASE_URL=https://openapivts.koreainvestment.com:29443
# 실전 서버 사용시 아래로 변경
# KIS_BASE_URL=https://openapi.koreainvestment.com:9443

KIS_APP_KEY=여기에_APP_KEY
KIS_APP_SECRET=여기에_APP_SECRET

# 계좌 조회가 필요할 때만 설정
KIS_APP_ID=YOUR_ACCOUNT_ID
KIS_APP_PASSWORD=YOUR_ACCOUNT_PASSWORD

NODE_ENV=production
```

---

## 📌 Python용 Dockerfile (`python/Dockerfile`)

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

RUN mkdir -p /app/data
```

---

## 📌 Node용 Dockerfile (`node/Dockerfile`)

```dockerfile
FROM node:20-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .

EXPOSE 3000
CMD ["npm", "run", "start"]
```

---

# 🎯 **실행 방법 (Windows 기준)**

```powershell
cd D:\ai\Lee_trader
docker compose up --build
```

* python-pipeline → run_pipeline.py 실행 후 종료
* node-api → [http://localhost:3000](http://localhost:3000) 에서 API 실행됨
* data/ 폴더에 CSV 파일 생성됨

백그라운드 실행:

```powershell
docker compose up -d
```

중지:

```powershell
docker compose down
```

---

# 👍 복사 시 인코딩 깨질 요소 모두 제거됨

* 모든 코드 블록은 UTF-8 안전 문자만 포함
* 특수 따옴표 없음
* BOM 필요 없음
* Windows 메모장/VSCode/Notepad++ 전부 안전하게 동작함

---

필요하면
✔ run_pipeline.py 템플릿
✔ requirements.txt 템플릿
✔ Node API 기본 구조
까지 **연속해서 자동 생성**해줄게.

다음 단계 무엇으로 갈까?
