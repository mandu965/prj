지금 제공한 PRD(3.1 버전)를 **완전히 다시 정비해서**,
**“도커 기반 실행 환경(Docker + Docker Compose)”까지 포함한 최종 PRD(4.0 버전)** 으로 만들어줄게.

아래 PRD는:

✔ 한국투자 API 기반 데이터 파이프라인
✔ ML 예측 시스템
✔ Node API
✔ Web Frontend
✔ 운영/배포 자동화
✔ Docker / Compose 기반 통합 실행 구조

까지 모두 포함한 **최종, 완성형 PRD**야.

---

# 📘 **PRD (Product Requirements Document)**

## **AI 기반 한국 주식 스코어링 & 3개월 수익률 예측 시스템 – Docker 버전**

**버전 4.0 — 한국투자증권 API + Docker 기반 최종 PRD**

---

# 0. 문서 개요

## 0.1 목적

본 문서는 “한국투자증권 OpenAPI 기반 한국 주식 분석 및 ML 예측 시스템”을 **어떤 환경에서도 재현 가능하게 Docker 기반으로 실행**할 수 있도록
전체 요구사항을 상세히 정리한 완성형 PRD이다.

---

# 1. 프로젝트 개요

## 1.1 프로젝트명

**AI Stock Analyzer – Docker Edition**

## 1.2 주요 기능

1. 한국투자증권 API로 **정확한 한국 주가 수집**
2. Python ML 파이프라인으로 **특징 생성, 점수 산출, 예측**
3. Node API로 **데이터 제공**
4. Web UI로 **종목 리스트/상세 분석 화면 제공**
5. Docker 기반으로 **어디서든 동일한 환경에서 실행 가능**

---

# 2. 전체 시스템 구성도 (Docker 포함)

```
                   ┌─────────────────────────────┐
                   │         Web Frontend         │
                   │ index.html / detail.html     │
                   └────────────▲────────────────┘
                                │ HTTP (3000)
                        ┌───────┴────────────────┐
                        │       Node.js API       │
                        │   /api/stocks           │
                        │   /api/stocks/:code     │
                        └────────────▲────────────┘
                                     │
                          CSV 파일 로딩 (Docker Volume)
                                     │
                 ┌───────────────────┴─────────────────────┐
                 │          Python ML Pipeline             │
                 │  1. 수집(download_prices_kis.py)        │
                 │  2. 정제(clean_prices.py)               │
                 │  3. 특징(feature_builder.py)            │
                 │  4. 점수(scoring.py)                    │
                 │  5. 라벨(label_builder.py)              │
                 │  6. 학습(model_train.py)                │
                 │  7. 예측(model_predict.py)              │
                 └───────────────────▲─────────────────────┘
                                     │
                               Docker Volume
                                     │
                        /app/data/*.csv 파일 저장
```

---

# 3. Docker 기반 실행 구조

이 프로젝트는 **Docker Compose** 와 **두 개의 컨테이너**로 구성된다.

## 3.1 containers

### 🐍 **1) python-pipeline 컨테이너**

* 역할:

  * 한국투자 시세/재무 데이터 수집
  * Feature 생성
  * 점수 계산
  * ML 예측 수행

* 출력:

  * `/app/data/*.csv`

* 실행 방식:

  * compose 실행 시 1회 실행
  * 또는 스케줄러 기반 cron 실행 컨테이너(선택)

### 🟩 **2) node-api 컨테이너**

* 역할:

  * CSV 읽기 → API 응답 반환
  * `/api/stocks`, `/api/stocks/:code`
* 포트:

  * 3000 → 브라우저 접근

---

### 3.2 docker-compose.yml 요구사항

```
version: '3.9'

services:

  python-pipeline:
    build: ./python
    container_name: stock_pipeline
    volumes:
      - ./data:/app/data
    environment:
      - KIS_APP_KEY=${KIS_APP_KEY}
      - KIS_APP_SECRET=${KIS_APP_SECRET}
      - KIS_APP_ID=${KIS_APP_ID}
      - KIS_APP_PASSWORD=${KIS_APP_PASSWORD}
    command: ["python", "run_pipeline.py"]

  node-api:
    build: ./node
    container_name: stock_api
    ports:
      - "3000:3000"
    volumes:
      - ./data:/app/data
    environment:
      - KIS_APP_KEY=${KIS_APP_KEY}
      - KIS_APP_SECRET=${KIS_APP_SECRET}
```

환경변수는 `.env` 파일로 관리:

```
KIS_APP_KEY=xxxx
KIS_APP_SECRET=xxxx
KIS_APP_ID=xxxx
KIS_APP_PASSWORD=xxxx
```

---

# 4. 데이터 소스 (한국투자 API)

## 일별 시세 API

`GET /uapi/domestic-stock/v1/quotations/inquire-daily-itemchartprice`

## 실시간 가격 API

`GET /uapi/domestic-stock/v1/quotations/inquire-price`

## 종목 검색 API

`GET /uapi/domestic-stock/v1/quotations/inquire-search`

## 인증

`POST /oauth2/tokenP`

* 토큰 만료 체크
* 자동 재발급

---

# 5. Python 데이터 파이프라인 (Docker 내부 실행)

파이프라인 실행 순서:

```
run_pipeline.py
    → download_prices_kis.py
    → clean_prices.py
    → feature_builder.py
    → scoring.py
    → label_builder.py
    → model_train.py
    → model_predict.py
```

출력 CSV:

* prices_daily.csv
* features.csv
* labels.csv
* scores_final.csv
* predictions.csv

---

# 6. Node.js API 요구사항

## `/api/stocks`

반환:

| code | name | current_price | return_3m | pred_return_3m | growth_score |

정렬 옵션:

* sortBy = current_price, return_3m, pred_return_3m, growth_score
* order = asc/desc

## `/api/stocks/:code`

반환:

* 기본 종목 정보
* 성장점수
* 기술지표
* 최근 90일 시세
* 예측 수익률

---

# 7. Web UI 요구사항

## index.html

표시:

* 코드
* 이름
* 현재가
* 3개월 수익률
* 예측 3개월 수익률

기능:

* 정렬
* 검색
* 색상 규칙(양수: red, 음수: blue)

## detail.html

표시:

* 종목명
* 현재가
* 성장점수
* 예측 수익률
* 90일 가격 차트
* 가격 테이블

---

# 8. ML 요구사항

* 입력: 최근 60일 기술·재무 지표
* 출력: 다음 60일 수익률
* 모델: XGBoost
* 평가:

  * RMSE, MAE, MAPE, R²
  * 백테스트: Top 10 종목 대비 KOSPI 수익률 비교

---

# 9. 운영 요구사항

### Docker 기반 자동화

* 파이프라인은 Docker에서 실행 → 결과는 volume에 저장
* Node API도 Docker에서 실행 → 최신 CSV 즉시 반영
* `.env` 파일로 민감정보 관리

### 로그

* 파이프라인 로그: `/app/log`
* API 로그: `node/log`

---

# 10. 확장 계획

## 1단계

* 파이프라인 + API + UI + Docker 실행

## 2단계

* 종목 350개 확장
* 재무제표 크롤링(DART + OpenDART)

## 3단계

* 사용자 포트폴리오 최적화
* 종목 알림(가격/예측 변화)

## 4단계

* 전체 웹 서비스화
* 로그인/DB/백엔드 분리

---

# 📌 최종 결론

현재 PRD(4.0 버전)는:

✔ 한국투자증권 API
✔ Python ML 파이프라인
✔ Node.js API
✔ Web 프론트
✔ Docker 실행 구조
✔ 운영/확장 전략

까지 포함한 **완전한 개발 문서**이다.

---

원하면 다음을 바로 만들어줄 수 있어:

### ✔ Dockerfile (Python 버전 / Node 버전)

### ✔ docker-compose.yml 완성본

### ✔ run_pipeline.py 템플릿

### ✔ 전체 폴더 구조 자동 생성

### ✔ 한국투자 API 인증 모듈 생성

필요한 걸 말해줘!



APP key
PSLpw9uoEXijUTAUfKi5vT7mZNAUoeOlCZbL

APP Secret
EcfwVMcVfYXGuANQziOPE4UVeG/Ptez3e1VTKPzVOPtGcNUNyGonkLR3pa5VOoe38TdblKOAddMQyKJ9fYyGs9R1KFMkjcvf6Aq1djr57g24WSBbSj76Zi+wJ1gOIsfZtl1P2sVMiOeYceEdYJgZGH40BWBRHbF2IfQF+ZfUI1x3k43SkgY=