# bootstrap.ps1
# Lee_trader 프로젝트 기본 구조 및 파일 자동 생성 스크립트

param(
    [string]$ProjectRoot = "."
)

# 1. 루트 경로 설정
$root = Resolve-Path $ProjectRoot
Write-Host "프로젝트 루트: $root"

# 2. 폴더 생성
$pythonDir = Join-Path $root "python"
$nodeDir   = Join-Path $root "node"
$dataDir   = Join-Path $root "data"

New-Item -ItemType Directory -Force -Path $pythonDir | Out-Null
New-Item -ItemType Directory -Force -Path $nodeDir   | Out-Null
New-Item -ItemType Directory -Force -Path $dataDir   | Out-Null

Write-Host "폴더 생성 완료: python, node, data"

# 3. docker-compose.yml 생성
$composePath = Join-Path $root "docker-compose.yml"
@"
version: "3.9"

services:
  python-pipeline:
    build: ./python
    container_name: lee_trader_pipeline
    working_dir: /app
    command: ["python", "run_pipeline.py"]
    volumes:
      - ./data:/app/data
    env_file:
      - .env
    restart: "no"

  node-api:
    build: ./node
    container_name: lee_trader_api
    working_dir: /app
    command: ["npm", "run", "start"]
    ports:
      - "3000:3000"
    volumes:
      - ./data:/app/data
    env_file:
      - .env
    restart: unless-stopped
"@ | Set-Content -Encoding UTF8 $composePath

Write-Host "docker-compose.yml 생성 완료"

# 4. .env 템플릿 생성
$envPath = Join-Path $root ".env"
@"
# KIS OPEN API BASE URL
# 모의투자 서버
KIS_BASE_URL=https://openapivts.koreainvestment.com:29443
# 실전 서버 사용시 아래로 변경
# KIS_BASE_URL=https://openapi.koreainvestment.com:9443

KIS_APP_KEY=YOUR_APP_KEY
KIS_APP_SECRET=YOUR_APP_SECRET
KIS_APP_ID=YOUR_ACCOUNT_ID
KIS_APP_PASSWORD=YOUR_ACCOUNT_PASSWORD

NODE_ENV=development
"@ | Set-Content -Encoding UTF8 $envPath

Write-Host ".env 템플릿 생성 완료"

# 5. python/Dockerfile 생성
$pyDocker = Join-Path $pythonDir "Dockerfile"
@"
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

RUN mkdir -p /app/data

"@ | Set-Content -Encoding UTF8 $pyDocker

Write-Host "python/Dockerfile 생성 완료"

# 6. python/requirements.txt 생성 (최소 패키지)
$reqPath = Join-Path $pythonDir "requirements.txt"
@"
requests
pandas
numpy
scikit-learn
xgboost
python-dotenv
"@ | Set-Content -Encoding UTF8 $reqPath

Write-Host "python/requirements.txt 생성 완료"

# 7. 파이프라인 스켈레톤 파일들 생성
$pyFiles = @(
    "run_pipeline.py",
    "download_prices_kis.py",
    "clean_prices.py",
    "feature_builder.py",
    "scoring.py",
    "label_builder.py",
    "model_train.py",
    "model_predict.py"
)

foreach ($f in $pyFiles) {
    $path = Join-Path $pythonDir $f
    if (-not (Test-Path $path)) {
        New-Item -ItemType File -Path $path | Out-Null
    }
}

# 7-1. run_pipeline.py 내용 작성
$runPipelinePath = Join-Path $pythonDir "run_pipeline.py"
@"
import subprocess
import sys
import logging
from datetime import datetime
from pathlib import Path

STEPS = [
    ("download_prices_kis", "download_prices_kis.py"),
    ("clean_prices", "clean_prices.py"),
    ("feature_builder", "feature_builder.py"),
    ("scoring", "scoring.py"),
    ("label_builder", "label_builder.py"),
    ("model_train", "model_train.py"),
    ("model_predict", "model_predict.py"),
]

def setup_logging() -> None:
    log_dir = Path("logs")
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"pipeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_file, encoding="utf-8"),
        ],
    )
    logging.info("==== Pipeline started ====")

def run_step(name: str, script: str) -> None:
    logging.info(f"▶ [{name}] 시작: {script}")
    script_path = Path(script)
    if not script_path.exists():
        logging.warning(f"  ! 스크립트가 아직 없습니다: {script_path.resolve()}")
        return
    result = subprocess.run([sys.executable, str(script_path)], check=False)
    if result.returncode != 0:
        logging.error(f"  ✖ [{name}] 실패 (return code={result.returncode})")
        raise RuntimeError(f"Step {name} failed with code {result.returncode}")
    logging.info(f"  ✔ [{name}] 완료")

def main() -> None:
    setup_logging()
    try:
        for name, script in STEPS:
            run_step(name, script)
    except Exception as e:
        logging.exception(f"파이프라인 실행 중 오류 발생: {e}")
        logging.info("==== Pipeline failed ====")
        sys.exit(1)
    logging.info("==== Pipeline finished successfully ====")

if __name__ == "__main__":
    main()
"@ | Set-Content -Encoding UTF8 $runPipelinePath

# 나머지 파이프라인 파일은 간단한 템플릿만 넣어줌
function Write-PyStub($name, $title) {
    $p = Join-Path $pythonDir $name
    if ((Get-Content $p -ErrorAction SilentlyContinue).Length -eq 0) {
        @"
print("[$title] TODO: 구현 필요")
"@ | Set-Content -Encoding UTF8 $p
    }
}

Write-PyStub "download_prices_kis.py" "download_prices_kis"
Write-PyStub "clean_prices.py"         "clean_prices"
Write-PyStub "feature_builder.py"      "feature_builder"
Write-PyStub "scoring.py"              "scoring"
Write-PyStub "label_builder.py"        "label_builder"
Write-PyStub "model_train.py"          "model_train"
Write-PyStub "model_predict.py"        "model_predict"

Write-Host "Python 파이프라인 스켈레톤 생성 완료"

# 8. node/Dockerfile 생성
$nodeDocker = Join-Path $nodeDir "Dockerfile"
@"
FROM node:20

WORKDIR /app

COPY package*.json ./
RUN npm install --legacy-peer-deps

COPY . .

EXPOSE 3000
CMD ["npm", "run", "start"]
"@ | Set-Content -Encoding UTF8 $nodeDocker

Write-Host "node/Dockerfile 생성 완료"

# 9. node/package.json 생성 (최소 서버)
$pkgPath = Join-Path $nodeDir "package.json"
@"
{
  "name": "lee-trader-api",
  "version": "1.0.0",
  "description": "Minimal Node API for Lee trader project",
  "main": "index.js",
  "scripts": {
    "start": "node index.js"
  },
  "dependencies": {
    "express": "^4.19.2",
    "cors": "^2.8.5"
  }
}
"@ | Set-Content -Encoding UTF8 $pkgPath

# 10. node/index.js 생성
$indexJs = Join-Path $nodeDir "index.js"
@"
const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Lee trader API is running" });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
"@ | Set-Content -Encoding UTF8 $indexJs

Write-Host "Node 최소 API 생성 완료"

Write-Host "=== bootstrap 완료! ==="
Write-Host "이제 다음 명령으로 빌드/실행할 수 있습니다:"
Write-Host "  cd $root"
Write-Host "  docker compose up --build"
